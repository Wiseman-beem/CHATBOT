using CyberBot.Models;
using MySqlConnector;

namespace CyberBot.Services;

/// <summary>All MySQL access for the task assistant (full CRUD).</summary>
public class TaskRepository
{
    private string _connStr = "";
    public bool Available { get; private set; }

    private const string CreateTableSql = @"
        CREATE TABLE IF NOT EXISTS cyber_tasks (
            Id INT AUTO_INCREMENT PRIMARY KEY,
            Title VARCHAR(200) NOT NULL,
            Description VARCHAR(1000) NOT NULL,
            ReminderAt DATETIME NULL,
            IsCompleted TINYINT(1) NOT NULL DEFAULT 0,
            ReminderSent TINYINT(1) NOT NULL DEFAULT 0,
            CreatedAt DATETIME NOT NULL);";

    public async Task InitialiseAsync()
    {
        var builder = new MySqlConnectionStringBuilder
        {
            Server = DbConfig.Server,
            Port = DbConfig.Port,
            UserID = DbConfig.User,
            Password = DbConfig.Password
        };

        await using (var conn = new MySqlConnection(builder.ConnectionString))
        {
            await conn.OpenAsync();
            await using var cmd = new MySqlCommand(
                $"CREATE DATABASE IF NOT EXISTS `{DbConfig.Database}` CHARACTER SET utf8mb4;", conn);
            await cmd.ExecuteNonQueryAsync();
        }

        builder.Database = DbConfig.Database;
        _connStr = builder.ConnectionString;

        await using (var conn = new MySqlConnection(_connStr))
        {
            await conn.OpenAsync();
            await using var cmd = new MySqlCommand(CreateTableSql, conn);
            await cmd.ExecuteNonQueryAsync();
        }
        Available = true;
    }

    private async Task<MySqlConnection> OpenAsync()
    {
        var conn = new MySqlConnection(_connStr);
        await conn.OpenAsync();
        return conn;
    }

    // CREATE
    public async Task<int> AddAsync(TaskItem t)
    {
        await using var conn = await OpenAsync();
        await using var cmd = new MySqlCommand(
            "INSERT INTO cyber_tasks (Title, Description, ReminderAt, IsCompleted, ReminderSent, CreatedAt) " +
            "VALUES (@t, @d, @r, 0, 0, @c);", conn);
        cmd.Parameters.AddWithValue("@t", t.Title);
        cmd.Parameters.AddWithValue("@d", t.Description);
        cmd.Parameters.AddWithValue("@r", (object?)t.ReminderAt ?? DBNull.Value);
        cmd.Parameters.AddWithValue("@c", t.CreatedAt);
        await cmd.ExecuteNonQueryAsync();
        return (int)cmd.LastInsertedId;
    }

    // READ
    public async Task<List<TaskItem>> GetAllAsync()
    {
        var list = new List<TaskItem>();
        await using var conn = await OpenAsync();
        await using var cmd = new MySqlCommand(
            "SELECT Id, Title, Description, ReminderAt, IsCompleted, ReminderSent, CreatedAt " +
            "FROM cyber_tasks ORDER BY IsCompleted, Id;", conn);
        await using var r = await cmd.ExecuteReaderAsync();
        while (await r.ReadAsync()) list.Add(Map(r));
        return list;
    }

    // UPDATE
    public async Task SetReminderAsync(int id, DateTime? when)
    {
        await using var conn = await OpenAsync();
        await using var cmd = new MySqlCommand(
            "UPDATE cyber_tasks SET ReminderAt = @r, ReminderSent = 0 WHERE Id = @id;", conn);
        cmd.Parameters.AddWithValue("@r", (object?)when ?? DBNull.Value);
        cmd.Parameters.AddWithValue("@id", id);
        await cmd.ExecuteNonQueryAsync();
    }

    public async Task CompleteAsync(int id)
    {
        await using var conn = await OpenAsync();
        await using var cmd = new MySqlCommand("UPDATE cyber_tasks SET IsCompleted = 1 WHERE Id = @id;", conn);
        cmd.Parameters.AddWithValue("@id", id);
        await cmd.ExecuteNonQueryAsync();
    }

    // DELETE
    public async Task DeleteAsync(int id)
    {
        await using var conn = await OpenAsync();
        await using var cmd = new MySqlCommand("DELETE FROM cyber_tasks WHERE Id = @id;", conn);
        cmd.Parameters.AddWithValue("@id", id);
        await cmd.ExecuteNonQueryAsync();
    }

    // Reminder support
    public async Task<List<TaskItem>> GetDueAsync(DateTime now)
    {
        var list = new List<TaskItem>();
        await using var conn = await OpenAsync();
        await using var cmd = new MySqlCommand(
            "SELECT Id, Title, Description, ReminderAt, IsCompleted, ReminderSent, CreatedAt FROM cyber_tasks " +
            "WHERE ReminderAt IS NOT NULL AND ReminderAt <= @now AND ReminderSent = 0 AND IsCompleted = 0;", conn);
        cmd.Parameters.AddWithValue("@now", now);
        await using var r = await cmd.ExecuteReaderAsync();
        while (await r.ReadAsync()) list.Add(Map(r));
        return list;
    }

    public async Task MarkReminderSentAsync(int id)
    {
        await using var conn = await OpenAsync();
        await using var cmd = new MySqlCommand("UPDATE cyber_tasks SET ReminderSent = 1 WHERE Id = @id;", conn);
        cmd.Parameters.AddWithValue("@id", id);
        await cmd.ExecuteNonQueryAsync();
    }

    private static TaskItem Map(MySqlDataReader r) => new()
    {
        Id = r.GetInt32(0),
        Title = r.GetString(1),
        Description = r.GetString(2),
        ReminderAt = r.IsDBNull(3) ? null : r.GetDateTime(3),
        IsCompleted = r.GetBoolean(4),
        ReminderSent = r.GetBoolean(5),
        CreatedAt = r.GetDateTime(6)
    };
}
