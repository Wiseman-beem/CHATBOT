using CyberBot.Models;

namespace CyberBot.Services;

/// <summary>In-memory record of everything the bot has done, newest last.</summary>
public class ActivityLog
{
    private readonly List<LogEntry> _entries = new();
    public event Action? Changed;
    public int Count => _entries.Count;

    public void Add(string category, string description)
    {
        _entries.Add(new LogEntry(DateTime.Now, category, description));
        Changed?.Invoke();
    }

    /// <summary>Most recent entries first. skip/count allow "show more" paging.</summary>
    public List<LogEntry> GetRecent(int count, int skip = 0) =>
        Enumerable.Reverse(_entries).Skip(skip).Take(count).ToList();
}
