namespace CyberBot.Services;

/// <summary>MySQL settings. Override with environment variables so no password lives in source control.</summary>
public static class DbConfig
{
    public static string Server => Environment.GetEnvironmentVariable("CYBERBOT_DB_HOST") ?? "localhost";
    public static uint Port => 3306;
    public static string User => Environment.GetEnvironmentVariable("CYBERBOT_DB_USER") ?? "root";
    public static string Password => Environment.GetEnvironmentVariable("CYBERBOT_DB_PASSWORD") ?? "";
    public const string Database = "cyberbot";
}
