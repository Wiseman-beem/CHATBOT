using CyberBot.Models;

namespace CyberBot.Services;

public class QuizEngine
{
    private readonly Random _rng = new();
    private List<QuizQuestion> _questions = new();
    private int _index;

    public int Score { get; private set; }
    public int Total => _questions.Count;
    public int Number => _index + 1;
    public QuizQuestion Current => _questions[_index];
    public bool HasNext => _index < _questions.Count - 1;

    public void Start()
    {
        _questions = Bank.OrderBy(_ => _rng.Next()).ToList();
        _index = 0;
        Score = 0;
    }

    public bool Answer(int choice)
    {
        bool correct = choice == Current.CorrectIndex;
        if (correct) Score++;
        return correct;
    }

    public void Next() => _index++;

    public string FinalFeedback()
    {
        double pct = Total == 0 ? 0 : (double)Score / Total;
        if (pct >= 0.8) return "Great job! You're a cybersecurity pro!";
        if (pct >= 0.5) return "Good effort! A little more practice and you'll be a pro.";
        return "Keep learning to stay safe online!";
    }

    private static readonly string[] TF = { "True", "False" };

    private static QuizQuestion Q(string text, string[] options, int correct, string why) =>
        new() { Text = text, Options = options.ToList(), CorrectIndex = correct, Explanation = why };

    private static readonly List<QuizQuestion> Bank = new()
    {
        Q("What should you do if you receive an email asking for your password?",
          new[] { "Reply with your password", "Delete the email", "Report the email as phishing", "Ignore it" }, 2,
          "Reporting phishing emails helps prevent scams. Legitimate companies never ask for your password by email."),
        Q("True or false: It is safe to use the same password on all of your accounts.",
          TF, 1, "If one site is breached, attackers try that password everywhere. Use a unique password per account."),
        Q("True or false: A long password mixing letters, numbers and symbols is generally stronger.",
          TF, 0, "Length and variety make passwords much harder to guess or brute-force."),
        Q("What is phishing?",
          new[] { "A hobby involving fish", "Fraudulent messages that trick you into revealing information", "A type of firewall", "A way to speed up your PC" }, 1,
          "Phishing uses fake emails, texts or sites that pretend to be trustworthy to steal your details."),
        Q("What does the padlock and https:// in your browser's address bar tell you?",
          new[] { "The site is 100% safe", "The connection to the site is encrypted", "The site has no ads", "The site is government-approved" }, 1,
          "HTTPS encrypts data in transit, but a scam site can still use it. Always check the domain too."),
        Q("What is social engineering?",
          new[] { "Building social media apps", "Manipulating people into giving up confidential information", "Encrypting messages", "Updating software" }, 1,
          "Attackers exploit trust and urgency rather than technical flaws, so staying sceptical is your best defence."),
        Q("True or false: Public Wi-Fi without a VPN is always safe for online banking.",
          TF, 1, "Open networks can be monitored or spoofed. Use mobile data or a trusted VPN for sensitive tasks."),
        Q("What does two-factor authentication (2FA) add to your login?",
          new[] { "A longer password", "A second proof of identity, like a code or app prompt", "Faster sign-in", "Automatic backups" }, 1,
          "Even if your password is stolen, the attacker still needs your second factor."),
        Q("True or false: Software updates often include important security fixes.",
          TF, 0, "Updates patch known vulnerabilities, so install them promptly."),
        Q("Someone calls claiming to be your bank and asks for the one-time PIN sent to your phone. What do you do?",
          new[] { "Read it out - they're the bank", "Hang up and call the bank on its official number", "Ask them to email you", "Share only half of it" }, 1,
          "Banks never ask for OTPs. Scammers create urgency, so verify using a number you trust."),
        Q("What is the safest way to manage many strong, unique passwords?",
          new[] { "Write them on a sticky note", "Use one password with small variations", "Use a reputable password manager", "Save them in a text file on your desktop" }, 2,
          "A password manager generates and stores unique passwords securely, protected by one strong master password."),
        Q("True or false: Ransomware locks or encrypts your files and demands payment.",
          TF, 0, "Regular offline backups are the best protection - you can restore without paying criminals."),
    };
}
