# CyberBot - Cybersecurity Awareness Chatbot (Part 3 / POE)

A WPF (XAML) desktop chatbot that teaches cybersecurity. Built with C# on .NET 8, with MySQL for task storage.

## Features
| Feature | Where |
|---|---|
| Chat with name memory, keyword recognition, sentiment detection, varied replies (Parts 1-2) | Chat tab |
| Task assistant: add / view / complete / delete tasks with optional reminders, stored in MySQL | Tasks tab + chat |
| Reminder system: due reminders pop into the chat automatically (checked every 20 s) | Chat |
| Cybersecurity quiz: 12 questions (multiple-choice + true/false), instant feedback, final score | Quiz tab + chat ("start quiz") |
| NLP simulation: keyword + regex detection, many phrasings | Chat |
| Activity log: last 10 actions, "Show more" | Log tab + chat ("show activity log") |

## Requirements
- Windows 10/11 and the **.NET 8 SDK**
- **MySQL Server** 8.x running locally (the app creates the `cyberbot` database and `cyber_tasks` table itself)

## Setup
1. Clone the repo.
2. Set your MySQL login (defaults: host `localhost`, user `root`, empty password). In PowerShell:
   ```powershell
   $env:CYBERBOT_DB_USER = "root"
   $env:CYBERBOT_DB_PASSWORD = "your-password"
   # optional: $env:CYBERBOT_DB_HOST = "localhost"
   ```
3. Run:
   ```powershell
   dotnet restore
   dotnet run
   ```
   (or open `CyberBot.csproj` in Visual Studio 2022 and press F5).

The status bar at the bottom shows whether MySQL is connected.

## Example things to type
- `Add task - Review privacy settings` -> bot asks about a reminder -> `Yes, remind me in 3 days`
- `Can you remind me to update my password?`
- `Add a task to enable 2FA in 2 weeks`
- `Show my tasks`, `Complete task 1`, `Delete task 2`
- `Start quiz`
- `Show activity log` / `What have you done?` then `show more`
- `I'm worried about phishing`, `Tell me more`, `I'm interested in VPNs`

## Project structure
```
CyberBot/
  MainWindow.xaml(.cs)    GUI: Chat, Tasks, Quiz and Activity Log tabs
  App.xaml                Styles (button templates)
  Models/Models.cs        TaskItem, QuizQuestion, ChatMessage, LogEntry
  Services/ChatBot.cs     Conversation logic and state
  Services/NlpEngine.cs   Intent detection, date parsing, title extraction
  Services/KnowledgeBase.cs  Topics and varied responses
  Services/TaskRepository.cs MySQL CRUD
  Services/QuizEngine.cs  Question bank and scoring
  Services/ActivityLog.cs Action history
  schema.sql              Database schema (also created automatically)
```

## Links
- YouTube walkthrough (unlisted): _add link here_
- GitHub repository: _add link here_
