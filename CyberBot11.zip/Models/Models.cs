namespace CyberBot.Models;

public class TaskItem
{
    public int Id { get; set; }
    public string Title { get; set; } = "";
    public string Description { get; set; } = "";
    public DateTime? ReminderAt { get; set; }
    public bool IsCompleted { get; set; }
    public bool ReminderSent { get; set; }
    public DateTime CreatedAt { get; set; }

    public string ReminderText => ReminderAt?.ToString("yyyy-MM-dd HH:mm") ?? "None";
    public string StatusText => IsCompleted ? "Completed" : "Pending";
}

public class QuizQuestion
{
    public string Text { get; set; } = "";
    public List<string> Options { get; set; } = new();
    public int CorrectIndex { get; set; }
    public string Explanation { get; set; } = "";
}

public class ChatMessage
{
    public string Text { get; set; } = "";
    public bool IsUser { get; set; }
    public string TimeText { get; set; } = DateTime.Now.ToString("HH:mm");
}

public record LogEntry(DateTime Time, string Category, string Description)
{
    public override string ToString() => $"[{Time:HH:mm:ss}]  {Category} - {Description}";
}
