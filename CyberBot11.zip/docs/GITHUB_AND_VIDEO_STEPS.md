# GitHub steps (rubric: 6+ commits, a release with 3+ tags)

Commit as you go, using clear messages. Suggested sequence:
1. `git init`, add `.gitignore` -> "Add project skeleton and .gitignore"
2. Add `Models/` and `Services/ActivityLog.cs` -> "Add models and activity log"
3. Add `Services/TaskRepository.cs`, `DbConfig.cs`, `schema.sql` -> "Add MySQL task repository with CRUD"
4. Add `NlpEngine.cs`, `KnowledgeBase.cs`, `ChatBot.cs` -> "Add NLP intent detection and chatbot logic"
5. Add `QuizEngine.cs` -> "Add 12-question cybersecurity quiz engine"
6. Add `App.xaml`, `MainWindow.xaml(.cs)` -> "Add WPF GUI with chat, tasks, quiz and log tabs"
7. Add `README.md` -> "Add README with setup and usage"

Tags / release (create at least three, each with notes, and publish a GitHub Release):
```
git tag -a v0.1.0 <commit-after-step-3> -m "Database layer and models"
git tag -a v0.5.0 <commit-after-step-5> -m "NLP, chatbot logic and quiz engine"
git tag -a v1.0.0 -m "Complete Part 3: GUI, tasks, quiz, NLP, activity log"
git push origin main --tags
```
Then on GitHub: Releases -> Draft a new release -> pick a tag -> paste the version notes.

# Video outline (record it yourself, in your own voice)
1. Run the app, show the MySQL status bar
2. Walk through the code structure (ChatBot, NlpEngine, TaskRepository, MainWindow)
3. Demo: add a task via chat, set a reminder, view/complete/delete, and show the rows in MySQL
4. Demo NLP with varied phrasings
5. Demo the quiz end to end
6. Show the activity log and "Show more"
7. Show your GitHub commits and releases
