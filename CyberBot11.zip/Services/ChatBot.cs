using System.Text;
using System.Text.RegularExpressions;
using CyberBot.Models;

namespace CyberBot.Services;

public enum ChatState { None, AwaitingName, AwaitingTaskTitle, AwaitingReminderChoice, AwaitingReminderTime }

/// <summary>Chat brain: Part 1/2 features (name memory, keywords, sentiment) plus Part 3 (tasks, quiz, log, NLP).</summary>
public class ChatBot
{
    private const string DbDown = "I can't reach the MySQL database right now, so task features are switched off. " +
                                  "Check the README for database setup, then restart the app.";

    private readonly TaskRepository _repo;
    private readonly ActivityLog _log;
    private readonly Random _rng = new();

    private ChatState _state = ChatState.AwaitingName;
    private TaskItem? _pending;
    private string _userName = "";
    private string _favouriteTopic = "";
    private Topic? _lastTopic;
    private string _lastResponse = "";
    private int _logOffset;

    public event Action? TasksChanged;
    public event Action? StartQuizRequested;

    public ChatBot(TaskRepository repo, ActivityLog log)
    {
        _repo = repo;
        _log = log;
    }

    public string Greeting() =>
        "Hi there! I'm CyberBot, your cybersecurity awareness assistant. What's your name?";

    public async Task<string> HandleAsync(string input)
    {
        input = input.Trim();
        if (input.Length == 0) return "I'm listening - type a message or try 'help'.";
        string lower = input.ToLowerInvariant();

        if (_state == ChatState.AwaitingName) return HandleName(input);

        if (_state == ChatState.AwaitingTaskTitle)
        {
            _state = ChatState.None;
            if (NlpEngine.HasAny(lower, "cancel", "never mind", "nevermind")) return "No problem - task cancelled.";
            return await CreateTaskAsync(NlpEngine.ExtractTitle(input), NlpEngine.ParseWhen(lower));
        }

        if (_state == ChatState.AwaitingReminderChoice)
        {
            var due = NlpEngine.ParseWhen(lower);
            if (due != null) return await SetReminderAsync(due.Value);
            if (NlpEngine.IsNo(lower))
            {
                ClearPending();
                return "No problem - the task is saved without a reminder.";
            }
            if (NlpEngine.IsYes(lower))
            {
                _state = ChatState.AwaitingReminderTime;
                return "When should I remind you? For example: 'in 3 days', 'tomorrow', 'next week' or 2026-12-01.";
            }
            ClearPending(); // user moved on to something else - handle it normally
        }
        else if (_state == ChatState.AwaitingReminderTime)
        {
            var due = NlpEngine.ParseWhen(lower);
            if (due != null) return await SetReminderAsync(due.Value);
            if (NlpEngine.IsNo(lower))
            {
                ClearPending();
                return "Okay, no reminder. The task is still saved.";
            }
            return "I couldn't read that time. Try 'in 3 days', 'tomorrow' or 'next week' (or say 'no' to skip).";
        }

        return await RouteAsync(input, lower);
    }

    private async Task<string> RouteAsync(string input, string lower)
    {
        var intent = NlpEngine.Detect(lower);
        string namePart = _userName.Length > 0 ? $", {_userName}" : "";

        switch (intent)
        {
            case Intent.AddTask:
                _log.Add("NLP", $"Recognised an add-task request from: \"{Short(input)}\"");
                return await AddTaskAsync(input, lower);

            case Intent.ShowTasks:
                _log.Add("NLP", "Recognised a request to view tasks");
                return await ListTasksAsync();

            case Intent.CompleteTask:
                _log.Add("NLP", "Recognised a request to complete a task");
                return await ChangeTaskAsync(lower, delete: false);

            case Intent.DeleteTask:
                _log.Add("NLP", "Recognised a request to delete a task");
                return await ChangeTaskAsync(lower, delete: true);

            case Intent.StartQuiz:
                _log.Add("NLP", "Recognised a request to start the quiz");
                StartQuizRequested?.Invoke();
                return "Great - let's test your cybersecurity knowledge! I've opened the quiz for you.";

            case Intent.ShowLog:
                _logOffset = 0;
                return LogText(0);

            case Intent.ShowMore:
                return _logOffset > 0 ? LogText(_logOffset) : "There's nothing more to show. Try 'show activity log' first.";

            case Intent.Help:
                return "Here's what I can do:\n" +
                       "- Tasks: 'Add task - Enable 2FA', 'Remind me to update my password in 7 days', 'Show my tasks', 'Complete task 2', 'Delete task 3'\n" +
                       "- Quiz: 'Start quiz'\n" +
                       "- Activity log: 'Show activity log' or 'What have you done?'\n" +
                       "- Ask me about passwords, phishing, 2FA, VPNs, malware, privacy, Wi-Fi, backups and more.";

            case Intent.Thanks:
                return "You're welcome! Stay safe online.";

            case Intent.Exit:
                return $"Goodbye{namePart}! Remember: think before you click.";

            case Intent.HowAreYou:
                return "I'm running securely, thanks for asking! How can I help you stay safe online?";

            case Intent.Greeting:
                return _favouriteTopic.Length > 0
                    ? $"Hello{namePart}! Last time you mentioned {_favouriteTopic} - want a tip on that, or try 'help'?"
                    : $"Hello{namePart}! Ask me about cybersecurity, or try 'help' to see what I can do.";
        }

        return HandleGeneral(input, lower);
    }

    private string HandleGeneral(string input, string lower)
    {
        if (lower.Contains("my name") && lower.Contains("what"))
            return _userName.Length > 0 ? $"Your name is {_userName}." : "I don't know your name yet.";

        // Part 2: remember the user's favourite topic
        var interest = Regex.Match(lower, @"(?:interested in|care about|curious about|learn about|love|like)\s+(?:the\s+)?(.+)");
        if (interest.Success)
        {
            var t = FindTopic(interest.Groups[1].Value);
            if (t != null)
            {
                _favouriteTopic = t.Name;
                _lastTopic = t;
                _log.Add("NLP", $"Saved '{t.Name}' as the user's favourite topic");
                return $"Great - I'll remember you're interested in {t.Name}. " + Pick(t.Responses);
            }
        }

        // "tell me more" follow-up
        if (_lastTopic != null && NlpEngine.HasAny(lower, "tell me more", "more info", "explain", "another tip"))
            return Pick(_lastTopic.Responses);

        string? sentiment = NlpEngine.Sentiment(lower);
        string lead = sentiment != null && KnowledgeBase.SentimentLead.TryGetValue(sentiment, out var s) ? s : "";

        var topic = FindTopic(lower);
        if (topic != null)
        {
            _lastTopic = topic;
            _log.Add("NLP", $"Keyword detected - answered a question about {topic.Name}");
            string tail = _favouriteTopic.Length > 0 && topic.Name != _favouriteTopic
                ? $"\n(Since you like {_favouriteTopic}, ask me about that any time.)" : "";
            return lead + Pick(topic.Responses) + tail;
        }

        if (lead.Length > 0)
            return lead + "Ask me about passwords, phishing or 2FA, or type 'help' to see everything I can do.";

        return "I didn't quite understand that. Could you rephrase? You can ask about passwords, phishing or VPNs, " +
               "add a task, start the quiz, or type 'help'.";
    }

    // ---------- Tasks ----------

    private async Task<string> AddTaskAsync(string input, string lower)
    {
        if (!_repo.Available) return DbDown;
        string title = NlpEngine.ExtractTitle(input);
        if (title.Length == 0)
        {
            _state = ChatState.AwaitingTaskTitle;
            return "Sure - what's the task? For example: 'Enable two-factor authentication'.";
        }
        return await CreateTaskAsync(title, NlpEngine.ParseWhen(lower));
    }

    private async Task<string> CreateTaskAsync(string title, DateTime? due)
    {
        if (!_repo.Available) return DbDown;
        if (title.Length == 0) return "I couldn't work out the task title. Try 'Add task - Review privacy settings'.";

        var task = new TaskItem
        {
            Title = title,
            Description = NlpEngine.DescribeTask(title),
            ReminderAt = due,
            CreatedAt = DateTime.Now
        };
        task.Id = await _repo.AddAsync(task);
        _log.Add("Task", $"Task added: '{title}'");
        TasksChanged?.Invoke();

        if (due != null)
        {
            _log.Add("Reminder", $"Reminder set for '{title}' on {due:yyyy-MM-dd HH:mm}");
            return $"Task added with the description \"{task.Description}\"\nGot it! I'll remind you on {due:ddd, dd MMM yyyy HH:mm}.";
        }

        _pending = task;
        _state = ChatState.AwaitingReminderChoice;
        return $"Task added with the description \"{task.Description}\" Would you like a reminder?";
    }

    private async Task<string> SetReminderAsync(DateTime due)
    {
        if (_pending == null)
        {
            _state = ChatState.None;
            return "Hmm, I lost track of which task that was for. Try 'show my tasks'.";
        }
        await _repo.SetReminderAsync(_pending.Id, due);
        _log.Add("Reminder", $"Reminder set for '{_pending.Title}' on {due:yyyy-MM-dd HH:mm}");
        TasksChanged?.Invoke();
        ClearPending();
        return $"Got it! I'll remind you on {due:ddd, dd MMM yyyy HH:mm}.";
    }

    private async Task<string> ListTasksAsync()
    {
        if (!_repo.Available) return DbDown;
        var tasks = await _repo.GetAllAsync();
        if (tasks.Count == 0)
            return "You have no tasks yet. Try 'Add task - Enable two-factor authentication'.";

        var sb = new StringBuilder("Here are your tasks:");
        foreach (var t in tasks)
        {
            sb.Append($"\n#{t.Id} [{t.StatusText}] {t.Title}");
            sb.Append($"\n     {t.Description}");
            sb.Append($"\n     Reminder: {t.ReminderText}");
        }
        sb.Append("\nSay 'complete task <number>' or 'delete task <number>' to manage them.");
        return sb.ToString();
    }

    private async Task<string> ChangeTaskAsync(string lower, bool delete)
    {
        if (!_repo.Available) return DbDown;
        var m = Regex.Match(lower, @"(\d+)\b");
        if (!m.Success) return "Which task number? Say 'show my tasks' to see them.";

        int id = int.Parse(m.Groups[1].Value);
        var task = (await _repo.GetAllAsync()).FirstOrDefault(t => t.Id == id);
        if (task == null) return $"I couldn't find task #{id}. Say 'show my tasks' to see the numbers.";

        if (delete)
        {
            await _repo.DeleteAsync(id);
            _log.Add("Task", $"Task deleted: '{task.Title}'");
            TasksChanged?.Invoke();
            return $"Deleted task #{id}: '{task.Title}'.";
        }

        if (task.IsCompleted) return $"Task #{id} is already completed.";
        await _repo.CompleteAsync(id);
        _log.Add("Task", $"Task marked as completed: '{task.Title}'");
        TasksChanged?.Invoke();
        return $"Nice work! Task #{id} '{task.Title}' is marked as completed.";
    }

    /// <summary>Called by a timer; returns messages for any reminders that are now due.</summary>
    public async Task<List<string>> CheckRemindersAsync()
    {
        var messages = new List<string>();
        if (!_repo.Available) return messages;
        try
        {
            foreach (var t in await _repo.GetDueAsync(DateTime.Now))
            {
                await _repo.MarkReminderSentAsync(t.Id);
                _log.Add("Reminder", $"Reminder triggered for '{t.Title}'");
                messages.Add($"Reminder: '{t.Title}' - {t.Description}");
            }
        }
        catch
        {
            // a failed poll shouldn't crash the app; it will retry on the next tick
        }
        return messages;
    }

    // ---------- Helpers ----------

    private string HandleName(string input)
    {
        string name = Regex.Replace(input, @"^(?:my name is|i am|i'm|im|call me|it's|its)\s+", "", RegexOptions.IgnoreCase);
        var m = Regex.Match(name, @"[A-Za-z][A-Za-z'\-]*");
        name = m.Success ? m.Value : "friend";
        _userName = char.ToUpper(name[0]) + name.Substring(1).ToLowerInvariant();
        _state = ChatState.None;
        _log.Add("Chat", $"User introduced themselves as {_userName}");
        return $"Nice to meet you, {_userName}! I can manage your cybersecurity tasks and reminders, quiz you, " +
               "or answer questions about staying safe online. Type 'help' to see everything.";
    }

    private string LogText(int skip)
    {
        var items = _log.GetRecent(10, skip);
        if (items.Count == 0)
            return skip == 0 ? "The activity log is empty so far." : "That's everything in the log.";

        var sb = new StringBuilder(skip == 0 ? "Here's a summary of recent actions:" : "Earlier actions:");
        int n = skip + 1;
        foreach (var e in items)
        {
            sb.Append($"\n{n}. {e.Time:HH:mm} - {e.Description}");
            n++;
        }
        _logOffset = skip + items.Count;
        if (_logOffset < _log.Count) sb.Append("\nType 'show more' to see earlier actions.");
        return sb.ToString();
    }

    private static Topic? FindTopic(string text) =>
        KnowledgeBase.Topics.FirstOrDefault(t => NlpEngine.HasAny(text, t.Keys));

    private string Pick(string[] options)
    {
        string choice = options[_rng.Next(options.Length)];
        for (int i = 0; i < 5 && options.Length > 1 && choice == _lastResponse; i++)
            choice = options[_rng.Next(options.Length)];
        _lastResponse = choice;
        return choice;
    }

    private void ClearPending()
    {
        _pending = null;
        _state = ChatState.None;
    }

    private static string Short(string s) => s.Length <= 40 ? s : s.Substring(0, 37) + "...";
}
