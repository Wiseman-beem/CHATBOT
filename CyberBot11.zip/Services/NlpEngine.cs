using System.Text.RegularExpressions;

namespace CyberBot.Services;

public enum Intent
{
    Unknown, Greeting, HowAreYou, Help, AddTask, ShowTasks, CompleteTask, DeleteTask,
    StartQuiz, ShowLog, ShowMore, Thanks, Exit
}

/// <summary>
/// Simulated NLP using keyword detection (string.Contains) and regular expressions.
/// Tolerates different phrasings, e.g. "Add a task to enable 2FA", "Can you remind me to update my password?".
/// </summary>
public static class NlpEngine
{
    private const RegexOptions Ic = RegexOptions.IgnoreCase;
    private const string NumWords = "a|an|one|two|three|four|five|six|seven|eight|nine|ten";
    private const string Units = "hour|day|week|month";

    private static readonly Dictionary<string, int> NumberMap = new()
    {
        ["a"] = 1, ["an"] = 1, ["one"] = 1, ["two"] = 2, ["three"] = 3, ["four"] = 4, ["five"] = 5,
        ["six"] = 6, ["seven"] = 7, ["eight"] = 8, ["nine"] = 9, ["ten"] = 10
    };

    public static bool HasAny(string text, params string[] keys)
    {
        foreach (var k in keys)
            if (text.Contains(k)) return true;
        return false;
    }

    private static bool Rx(string text, string pattern) => Regex.IsMatch(text, pattern, Ic);

    public static Intent Detect(string l)
    {
        bool taskWord = HasAny(l, "task", "reminder", "to-do", "todo");
        bool addVerb = Rx(l, @"\b(add|create|new|make|set|schedule|put)\b");

        // explicit "add/create task" wins so that "Add task - finish 2FA" isn't read as a completion
        if (Rx(l, @"\b(add|create|new)\b") && taskWord) return Intent.AddTask;

        if (Rx(l, @"\b(delete|remove)\w*\s+(task\s*)?#?\d+\b")) return Intent.DeleteTask;
        if (Rx(l, @"\b(complete|finish|mark|done)\w*\s+(task\s*)?#?\d+\b")) return Intent.CompleteTask;

        if ((l.Contains("activity") && l.Contains("log")) ||
            HasAny(l, "what have you done", "what have i done", "show log", "view log")) return Intent.ShowLog;
        if (l.Contains("show more") || l.Trim() == "more") return Intent.ShowMore;

        if (HasAny(l, "quiz", "mini game", "mini-game", "minigame", "test me", "test my knowledge", "trivia"))
            return Intent.StartQuiz;

        if (l.Contains("remind me") || (addVerb && taskWord)) return Intent.AddTask;
        if (Rx(l, @"\b(show|view|list|display|see|check|what)\b") && taskWord) return Intent.ShowTasks;

        if (Rx(l, @"\b(help|commands)\b") || l.Contains("what can you do")) return Intent.Help;
        if (Rx(l, @"\b(thanks|thank you|cheers)\b")) return Intent.Thanks;
        if (Rx(l, @"\b(bye|goodbye|exit|quit)\b")) return Intent.Exit;
        if (l.Contains("how are you")) return Intent.HowAreYou;
        if (Rx(l, @"\b(hi|hello|hey|howzit)\b|good (morning|afternoon|evening)")) return Intent.Greeting;
        return Intent.Unknown;
    }

    public static string? Sentiment(string l)
    {
        if (HasAny(l, "worried", "scared", "afraid", "anxious", "nervous", "frightened", "concerned", "panic")) return "worried";
        if (HasAny(l, "frustrated", "annoyed", "confused", "overwhelmed", "angry", "stressed", "fed up")) return "frustrated";
        if (HasAny(l, "curious", "interested", "excited", "keen", "want to learn")) return "curious";
        if (HasAny(l, "happy", "great", "awesome", "love")) return "happy";
        return null;
    }

    public static bool IsYes(string l) => Rx(l, @"\b(yes|yeah|yep|sure|ok|okay|please|y)\b");
    public static bool IsNo(string l) => Rx(l, @"\b(no|nope|nah|not now|skip|cancel|n)\b");

    /// <summary>Understands "in 3 days", "in two weeks", "tomorrow", "next week", "2026-12-01".</summary>
    public static DateTime? ParseWhen(string text)
    {
        string s = text.ToLowerInvariant();
        DateTime now = DateTime.Now;

        var m = Regex.Match(s, $@"\b(\d+)\s*({Units})s?\b");
        if (m.Success) return AddSpan(now, int.Parse(m.Groups[1].Value), m.Groups[2].Value);

        m = Regex.Match(s, $@"\b(?:in|after|for)\s+({NumWords})\s+({Units})s?\b");
        if (m.Success) return AddSpan(now, NumberMap[m.Groups[1].Value], m.Groups[2].Value);

        if (s.Contains("tomorrow")) return now.Date.AddDays(1).AddHours(9);
        if (s.Contains("next week")) return now.AddDays(7);
        if (s.Contains("next month")) return now.AddMonths(1);

        m = Regex.Match(s, @"\b(\d{4}-\d{2}-\d{2})\b");
        if (m.Success && DateTime.TryParse(m.Groups[1].Value, out var d))
        {
            d = d.Date.AddHours(9);
            if (d > now) return d;
        }
        return null;
    }

    private static DateTime AddSpan(DateTime now, int n, string unit) => unit switch
    {
        "hour" => now.AddHours(n),
        "day" => now.AddDays(n),
        "week" => now.AddDays(7 * n),
        _ => now.AddMonths(n)
    };

    /// <summary>Strips command words and timeframe so only the task title remains.</summary>
    public static string ExtractTitle(string input)
    {
        string t = input.Trim();
        t = Regex.Replace(t, $@"\b(?:in|after)\s+(?:\d+|{NumWords})\s*(?:{Units})s?\b", "", Ic);
        t = Regex.Replace(t, @"\b(?:tomorrow|next week|next month)\b", "", Ic);
        t = Regex.Replace(t, @"\b\d{4}-\d{2}-\d{2}\b", "", Ic);
        t = Regex.Replace(t,
            @"^\s*(?:(?:please|hey|hi)\s*,?\s*)?(?:(?:can|could|would)\s+you\s+)?(?:please\s+)?" +
            @"(?:remind\s+me\s+(?:to\s+|about\s+)?|" +
            @"(?:add|create|make|new|set(?:\s+up)?|schedule|put)\s+(?:(?:a|an|new|my)\s+)*(?:task|reminder|to-do|todo)\s*(?:to\s+|for\s+|about\s+)?[-:]?\s*)",
            "", Ic);
        t = t.Trim(' ', '?', '.', '!', '-', ':', ',');
        t = Regex.Replace(t, @"\s{2,}", " ");
        return t.Length == 0 ? "" : char.ToUpper(t[0]) + t.Substring(1);
    }

    /// <summary>Gives each task a helpful, cybersecurity-flavoured description.</summary>
    public static string DescribeTask(string title)
    {
        string l = title.ToLowerInvariant();
        if (HasAny(l, "two-factor", "two factor", "2fa", "mfa"))
            return "Turn on two-factor authentication so a stolen password alone can't unlock your account.";
        if (l.Contains("privacy"))
            return "Review account privacy settings to ensure your data is protected.";
        if (l.Contains("password"))
            return "Use a strong, unique password (12+ characters) and store it in a password manager.";
        if (l.Contains("backup") || l.Contains("back up"))
            return "Back up important files so you can recover from ransomware or hardware failure.";
        if (l.Contains("vpn"))
            return "Use a trusted VPN on public networks to keep your traffic private.";
        if (HasAny(l, "update", "patch"))
            return "Install the latest security updates to close known vulnerabilities.";
        return $"Cybersecurity task: {title}. Completing it helps keep your accounts and data safe.";
    }
}
