namespace CyberBot.Services;

public record Topic(string Name, string[] Keys, string[] Responses);

/// <summary>Keyword -> several possible replies, so answers vary (dynamic responses).</summary>
public static class KnowledgeBase
{
    public static readonly List<Topic> Topics = new()
    {
        new("two-factor authentication", new[] { "2fa", "two-factor", "two factor", "mfa", "multi-factor", "authenticator" }, new[]
        {
            "Two-factor authentication adds a second check, like an app code, so a stolen password alone isn't enough. Enable it on email and banking first.",
            "Prefer an authenticator app over SMS codes when you can - it's harder for attackers to intercept.",
            "Save your 2FA backup codes somewhere safe. They're your way back in if you lose your phone."
        }),
        new("passwords", new[] { "password", "passphrase", "passcode" }, new[]
        {
            "Use long, unique passwords - 12+ characters, ideally a passphrase of random words. Never reuse one across accounts.",
            "A password manager lets you use a different strong password everywhere without memorising them. Pair it with 2FA.",
            "Avoid birthdays, pet names and keyboard patterns. Attackers try those first."
        }),
        new("phishing", new[] { "phishing", "suspicious email", "scam email", "fake email", "scam" }, new[]
        {
            "Phishing messages pretend to be someone you trust. Check the sender's address, hover over links before clicking, and be wary of urgency.",
            "If an email asks for your password or banking details, don't reply or click. Report it and contact the organisation via its official site.",
            "Red flags: spelling mistakes, generic greetings, unexpected attachments and threats like 'your account will be closed'."
        }),
        new("malware", new[] { "malware", "virus", "trojan", "spyware" }, new[]
        {
            "Malware is software built to harm or spy on you. Only install apps from trusted sources and keep antivirus and your OS updated.",
            "Be careful with email attachments and cracked software - they're common ways malware gets in."
        }),
        new("ransomware", new[] { "ransomware" }, new[]
        {
            "Ransomware encrypts your files and demands payment. Keep regular offline backups so you can restore without paying.",
            "Don't open unexpected attachments, keep systems patched, and back up often - those three stop most ransomware damage."
        }),
        new("VPNs", new[] { "vpn" }, new[]
        {
            "A VPN encrypts your traffic, which helps on public Wi-Fi. Choose a reputable provider - a shady VPN can be worse than none.",
            "A VPN protects your connection, not you from phishing or malware. It's one layer, not a complete solution."
        }),
        new("Wi-Fi safety", new[] { "wifi", "wi-fi", "public network", "router" }, new[]
        {
            "On public Wi-Fi avoid banking or logging in to sensitive accounts, or use a VPN. At home, change your router's default password.",
            "Use WPA2 or WPA3 on your home network and give the router a strong, unique admin password."
        }),
        new("privacy", new[] { "privacy", "personal data", "data protection", "personal information" }, new[]
        {
            "Review your privacy settings on social media and apps regularly. Share the minimum personal information needed.",
            "Check which apps can access your location, camera and contacts, and revoke what they don't need."
        }),
        new("social engineering", new[] { "social engineering", "pretexting", "impersonat" }, new[]
        {
            "Social engineering manipulates people rather than machines. If someone creates urgency or pressure, slow down and verify independently.",
            "Attackers pose as bosses, banks or tech support. Hang up and call back on an official number you trust."
        }),
        new("safe browsing", new[] { "browsing", "https", "website", "browser" }, new[]
        {
            "Look for HTTPS, but also check the domain spelling - scam sites can have padlocks too.",
            "Keep your browser updated, be careful with extensions, and don't download software from random pop-ups."
        }),
        new("software updates", new[] { "update", "patch" }, new[]
        {
            "Updates often fix security holes attackers already know about. Turn on automatic updates where you can.",
            "Delaying updates leaves known vulnerabilities open. Install them promptly."
        }),
        new("backups", new[] { "backup", "back up" }, new[]
        {
            "Follow the 3-2-1 idea: three copies, two types of storage, one kept off-site or offline.",
            "A backup you've never tested might not work. Try restoring a file occasionally."
        })
    };

    public static readonly Dictionary<string, string> SentimentLead = new()
    {
        ["worried"] = "It's completely understandable to feel worried - a few simple habits make a big difference. ",
        ["frustrated"] = "I hear you - cybersecurity can feel overwhelming. Let's take it one small step at a time. ",
        ["curious"] = "Love the curiosity! ",
        ["happy"] = "Glad to hear it! "
    };
}
