-- The app creates this automatically on start-up; run manually only if you prefer.
CREATE DATABASE IF NOT EXISTS cyberbot CHARACTER SET utf8mb4;
USE cyberbot;
CREATE TABLE IF NOT EXISTS cyber_tasks (
    Id           INT AUTO_INCREMENT PRIMARY KEY,
    Title        VARCHAR(200)  NOT NULL,
    Description  VARCHAR(1000) NOT NULL,
    ReminderAt   DATETIME      NULL,
    IsCompleted  TINYINT(1)    NOT NULL DEFAULT 0,
    ReminderSent TINYINT(1)    NOT NULL DEFAULT 0,
    CreatedAt    DATETIME      NOT NULL
);
