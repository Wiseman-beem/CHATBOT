using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using CyberBot.Models;
using CyberBot.Services;

namespace CyberBot;

public partial class MainWindow : Window
{
    private readonly ActivityLog _log = new();
    private readonly TaskRepository _repo = new();
    private readonly ChatBot _bot;
    private readonly QuizEngine _quiz = new();
    private readonly ObservableCollection<ChatMessage> _messages = new();
    private readonly DispatcherTimer _reminderTimer = new() { Interval = TimeSpan.FromSeconds(20) };
    private readonly Random _rng = new();
    private int _logShown = 10;
    private bool _quizActive;

    private static readonly string[] CorrectLeads = { "Correct!", "Spot on!", "Nice one!", "Exactly right!" };
    private static readonly string[] WrongLeads = { "Not quite.", "Oops - not this time.", "Close, but no.", "Good try!" };

    public MainWindow()
    {
        InitializeComponent();
        _bot = new ChatBot(_repo, _log);
        ChatList.ItemsSource = _messages;

        _log.Changed += RefreshLog;
        _bot.TasksChanged += async () => await RefreshTasksAsync();
        _bot.StartQuizRequested += () =>
        {
            Tabs.SelectedItem = QuizTab;
            StartQuiz();
        };

        _reminderTimer.Tick += async (_, _) => await CheckRemindersAsync();
        Loaded += async (_, _) => await OnLoadedAsync();
    }

    private async Task OnLoadedAsync()
    {
        AddMessage(_bot.Greeting(), false);
        try
        {
            await _repo.InitialiseAsync();
            DbStatus.Text = $"● MySQL connected ({DbConfig.Server}, database '{DbConfig.Database}')";
            await RefreshTasksAsync();
            _reminderTimer.Start();
            await CheckRemindersAsync();
        }
        catch (Exception ex)
        {
            DbStatus.Text = "● MySQL unavailable - task features disabled: " + ex.Message;
            AddMessage("Heads up: I couldn't connect to MySQL, so tasks won't work until it's running. " +
                       "See the README for setup.", false);
        }
        RefreshLog();
    }

    // ---------- Chat ----------

    private void AddMessage(string text, bool isUser)
    {
        _messages.Add(new ChatMessage { Text = text, IsUser = isUser });
        Dispatcher.BeginInvoke(new Action(() => ChatScroll.ScrollToEnd()), DispatcherPriority.Background);
    }

    private async Task SendAsync(string input)
    {
        input = input.Trim();
        if (input.Length == 0) return;
        InputBox.Clear();
        AddMessage(input, true);

        string reply;
        try { reply = await _bot.HandleAsync(input); }
        catch (Exception ex) { reply = "Sorry, something went wrong: " + ex.Message; }
        AddMessage(reply, false);
    }

    private async void Send_Click(object sender, RoutedEventArgs e) => await SendAsync(InputBox.Text);

    private async void Input_KeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Enter) await SendAsync(InputBox.Text);
    }

    private async void Chip_Click(object sender, RoutedEventArgs e)
    {
        if (sender is Button b && b.Tag is string text)
        {
            if (text == "Add task")
            {
                InputBox.Text = "Add task - ";
                InputBox.Focus();
                InputBox.CaretIndex = InputBox.Text.Length;
                return;
            }
            await SendAsync(text);
        }
    }

    private async Task CheckRemindersAsync()
    {
        foreach (var msg in await _bot.CheckRemindersAsync())
        {
            AddMessage("⏰ " + msg, false);
            await RefreshTasksAsync();
        }
    }

    // ---------- Tasks tab ----------

    private async Task RefreshTasksAsync()
    {
        if (!_repo.Available) return;
        try { TaskGrid.ItemsSource = await _repo.GetAllAsync(); }
        catch (Exception ex) { DbStatus.Text = "● Database error: " + ex.Message; }
    }

    private async void AddTask_Click(object sender, RoutedEventArgs e)
    {
        if (!_repo.Available) { MessageBox.Show("MySQL isn't connected."); return; }
        string title = NewTitle.Text.Trim();
        if (title.Length == 0) { MessageBox.Show("Please enter a task title."); return; }

        string desc = NewDescription.Text.Trim();
        DateTime? when = ReminderDate.SelectedDate?.Date.AddHours(9);
        var task = new TaskItem
        {
            Title = title,
            Description = desc.Length > 0 ? desc : NlpEngine.DescribeTask(title),
            ReminderAt = when,
            CreatedAt = DateTime.Now
        };
        try
        {
            await _repo.AddAsync(task);
            _log.Add("Task", $"Task added: '{title}'");
            if (when != null) _log.Add("Reminder", $"Reminder set for '{title}' on {when:yyyy-MM-dd HH:mm}");
            NewTitle.Clear();
            NewDescription.Clear();
            ReminderDate.SelectedDate = null;
            await RefreshTasksAsync();
            AddMessage($"Task added from the form: '{title}'.", false);
        }
        catch (Exception ex) { MessageBox.Show("Couldn't save the task: " + ex.Message); }
    }

    private async void Complete_Click(object sender, RoutedEventArgs e)
    {
        if (TaskGrid.SelectedItem is not TaskItem t) { MessageBox.Show("Select a task first."); return; }
        if (t.IsCompleted) return;
        await _repo.CompleteAsync(t.Id);
        _log.Add("Task", $"Task marked as completed: '{t.Title}'");
        await RefreshTasksAsync();
    }

    private async void Delete_Click(object sender, RoutedEventArgs e)
    {
        if (TaskGrid.SelectedItem is not TaskItem t) { MessageBox.Show("Select a task first."); return; }
        if (MessageBox.Show($"Delete '{t.Title}'?", "Confirm", MessageBoxButton.YesNo) != MessageBoxResult.Yes) return;
        await _repo.DeleteAsync(t.Id);
        _log.Add("Task", $"Task deleted: '{t.Title}'");
        await RefreshTasksAsync();
    }

    private async void Refresh_Click(object sender, RoutedEventArgs e) => await RefreshTasksAsync();

    // ---------- Quiz tab ----------

    private void StartQuiz_Click(object sender, RoutedEventArgs e) => StartQuiz();

    private void StartQuiz()
    {
        _quiz.Start();
        _quizActive = true;
        _log.Add("Quiz", "Quiz started");
        ShowQuestion();
    }

    private Button[] OptionButtons => new[] { Opt0, Opt1, Opt2, Opt3 };

    private void ShowQuestion()
    {
        var q = _quiz.Current;
        QuizProgress.Text = $"Question {_quiz.Number} of {_quiz.Total}   |   Score: {_quiz.Score}";
        QuizBar.Value = (double)(_quiz.Number - 1) / _quiz.Total;
        QuestionText.Text = q.Text;

        var buttons = OptionButtons;
        for (int i = 0; i < buttons.Length; i++)
        {
            if (i < q.Options.Count)
            {
                buttons[i].Visibility = Visibility.Visible;
                buttons[i].IsEnabled = true;
                buttons[i].Content = q.Options.Count == 2 ? q.Options[i] : $"{(char)('A' + i)})  {q.Options[i]}";
            }
            else buttons[i].Visibility = Visibility.Collapsed;
        }
        FeedbackText.Text = "";
        NextBtn.Visibility = Visibility.Collapsed;
        StartQuizBtn.Visibility = Visibility.Collapsed;
    }

    private void Option_Click(object sender, RoutedEventArgs e)
    {
        if (!_quizActive || sender is not Button btn) return;
        int choice = int.Parse((string)btn.Tag);
        var q = _quiz.Current;
        bool ok = _quiz.Answer(choice);

        foreach (var b in OptionButtons) b.IsEnabled = false;

        string correctText = q.Options[q.CorrectIndex];
        FeedbackText.Foreground = new SolidColorBrush(ok ? Color.FromRgb(0x2E, 0x7D, 0x4F) : Color.FromRgb(0xC0, 0x39, 0x2B));
        FeedbackText.Text = ok
            ? $"{CorrectLeads[_rng.Next(CorrectLeads.Length)]} {q.Explanation}"
            : $"{WrongLeads[_rng.Next(WrongLeads.Length)]} The right answer is: {correctText}. {q.Explanation}";

        QuizProgress.Text = $"Question {_quiz.Number} of {_quiz.Total}   |   Score: {_quiz.Score}";
        NextBtn.Content = _quiz.HasNext ? "Next question ▶" : "See my results 🏁";
        NextBtn.Visibility = Visibility.Visible;
    }

    private void Next_Click(object sender, RoutedEventArgs e)
    {
        if (_quiz.HasNext)
        {
            _quiz.Next();
            ShowQuestion();
            return;
        }
        FinishQuiz();
    }

    private void FinishQuiz()
    {
        _quizActive = false;
        foreach (var b in OptionButtons) b.Visibility = Visibility.Collapsed;
        QuizBar.Value = 1;
        QuizProgress.Text = "Quiz complete";
        QuestionText.Text = $"You scored {_quiz.Score} out of {_quiz.Total}.";
        FeedbackText.Foreground = new SolidColorBrush(Color.FromRgb(0x12, 0x35, 0x5B));
        FeedbackText.Text = _quiz.FinalFeedback();
        NextBtn.Visibility = Visibility.Collapsed;
        StartQuizBtn.Content = "↻ Play again";
        StartQuizBtn.Visibility = Visibility.Visible;

        _log.Add("Quiz", $"Quiz completed - score {_quiz.Score}/{_quiz.Total}");
        AddMessage($"🎯 Quiz finished: {_quiz.Score}/{_quiz.Total}. {_quiz.FinalFeedback()}", false);
    }

    // ---------- Activity log tab ----------

    private void RefreshLog()
    {
        var items = _log.GetRecent(_logShown);
        LogList.ItemsSource = items.Select(x => x.ToString()).ToList();
        LogCount.Text = $"Showing {items.Count} of {_log.Count} actions (newest first)";
        ShowMoreBtn.IsEnabled = items.Count < _log.Count;
    }

    private void ShowMore_Click(object sender, RoutedEventArgs e)
    {
        _logShown += 10;
        RefreshLog();
    }

    private void ShowLess_Click(object sender, RoutedEventArgs e)
    {
        _logShown = 10;
        RefreshLog();
    }
}
